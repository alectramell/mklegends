#!/bin/bash

clear

php -S localhost:8888

clear

sleep 0.5

echo "Server Has Been Closed.."

sleep 0.5
