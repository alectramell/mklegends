<?php
	$xtitle = 'Mortal Kombat';
	
	if (isset(POST['A001']))
	{
		shell_exec('python add.py "A001"');
	}
?>
<html>
<head>
<title>
<?php echo $xtitle; ?> 
</title>
<meta http-equiv="refresh" content="300;index.php">
<link type="image/icon" rel="icon" href="../img/favicon.ico">
<link type="text/css" rel="stylesheet" href="css/main.css">
<script type="text/javascript" src="js/index.js"></script>
</head>
<body>

<img id="bgImage" src="img/bg2.png">

<font id="titleText"><?php echo $xtitle; ?></font>
<font id="subText">Legends</font>

<div class="brEak"></div>

</body>
</html>
