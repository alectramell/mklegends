import os
import sys
import time
import socket
import platform

OSname = str(platform.system())

if OSname == "Windows":

# Windows Library..

	def clear():
	
		import os
		os.system('cls')

	def start():
	
		import os
		ZCOM = str('nohup php -S localhost:8888 > nohup.out')
		XCOM = str('START "C://Program Files (x86)/Google/Chrome/Application/chrom.exe" http://localhost:8888')
		os.system(ZCOM)
		time.sleep(0.5)
		os.system(XCOM)

elif OSname == "Linux":

# Linux Library..

	def clear():
	
		import os
		os.system('clear')

	def start():
	
		import os
		ZCOM = str('php -S localhost:8888')
		# ZCOM = str('nohup php -S localhost:8888 > nohup.out')
		# XCOM = str('google-chrome http://localhost:8888')
		os.system(ZCOM)
		time.sleep(0.5)
		# os.system(XCOM)
		
else:

# Universal Library..

	def clear():
	
		import os
		os.system('clear')
		
	def start():
	
		import os
		ZCOM = str('nohup php -S localhost:8888 > nohup.out')
		XCOM = str('google-chrome http://localhost:8888')
		os.system(ZCOM)
		time.sleep(0.5)
		os.system(XCOM)
		
clear()

time.sleep(1.5)

start()
